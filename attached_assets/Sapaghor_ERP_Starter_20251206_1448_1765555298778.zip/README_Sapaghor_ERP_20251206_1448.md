# Sapaghor ERP – Starter Pack

This pack gives you two things you can start using today:

1. **Excel mini‑ERP**: `Sapaghor_ERP_MVP_20251206_1448.xlsx` – track customers, orders, items, production stages, payments and delivery.
2. **Relational DB schema**: `sapaghor_schema_20251206_1448.sql` – ready for PostgreSQL when you move to a full web app.

## How to use the Excel file
- Open the **Settings** sheet; adjust lists (departments, statuses, materials, etc.).
- Add clients in **Customers**.
- Create a record in **Orders**; choose a **Status** from the drop‑down (mirrors your paper order card).
- Add line items in **OrderItems** (Amount auto‑calculates).
- Record payments in **Transactions** (Type has a drop‑down).
- Log work in **Production** (Stage + Dept drop‑downs) and add detail in **Design**, **Printing**, **Binding**.
- Mark the final row in **Delivery** when the job is handed over.
- See quick metrics in **Reports** (open orders, receivables, due this week).

## Mapping to your paper order sheet
- Header fields (Bill/Order No, dates, customer info) → **Orders**.
- *Order Details* table (Size, Quantity, Color, Paper, Binding, Others, Amount) → **OrderItems**.
- *Design Fee, Urgency Fee, Cashing Fee, Misc, Total* → columns in **Orders**.
- *Progress columns (Order → Design → Proof → … → Delivery)* → **Production** logs and **Status** on Orders.

## Next step (web app)
When ready, scaffold a Django/FastAPI backend using the SQL schema and expose endpoints for Orders, Items, Production, Transactions, and Delivery. A simple React/Vue admin UI can be layered on top. Keep Tally for accounting initially and sync invoices/receipts via CSV.

---

**Authoring date:** 2025-12-06 14:48